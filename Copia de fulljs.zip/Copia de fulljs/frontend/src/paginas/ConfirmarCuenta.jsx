import React from 'react'

const ConfirmarCuenta = () => {
  return (
    <>
      <h1>desde olvide ConfirmarCuenta</h1>
    </>
  )
}

export default ConfirmarCuenta;
